long long int calcula_subsidio_ferias(empregado *dados);
